<div id="wrap">
<header>
<div class = "title" class = "main">Название сайта</a></div>   
</header>
</div>
<div class="clear"></div>
</body>
</html>