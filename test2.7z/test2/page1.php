<?php 
    //Подключение шапки
    require_once("header.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href ="css/style.css" rel="stylesheet" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
<script type="text/javascript">
function showOrHide(bloggood, cat) {
	bloggood = document.getElementById(bloggood);
	cat = document.getElementById(cat);
		if (bloggood.checked) cat.style.display = "none";
		else cat.style.display = "block";
}
</script>
</head>
<body>
<left><h1>Запись на прием к врачу</h1></left>
	<div id="content2">
		<a href="main.php"><button class="back">Вернуться</button></a>
		<p class="text1">Прикрепитесь к медицинской организации или попросите прикрепиться того, кого хотите записать на прием к врачу</p>
		<p><input type = 'checkbox' checked  class = 'bloggood1' id="bloggood1" onchange = 'showOrHide("bloggood1", "cat1");'/>Прикрепление уже есть</p>
		<div id = 'cat1' style = 'display: none;'><li class="page1">Для прикрепления надо выбрать поликлинику по месту регистрации или жительства.</li><li class="page1">Затем требуется обратиться в регистратуру поликлиники для подачи заявления о прикреплении к медицинской организации.</li><li class="page1">С собой необходимо иметь следующие документы:</li></div>
	</div>
</body>
</html>
<?php 
    //Подключение подвала
    require_once("footer.php");
?>