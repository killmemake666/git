<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link href ="css/style.css" rel="stylesheet" type="text/css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>AJAX</title>
  <style>
  </style>
</head>
<body>
<?php 
    //Подключение шапки
    require_once("header.php");
?>
<div id = "container">
    <form id = "form_1">
        Email:<br>
        <input type="email" name="email"><br>
        Телефон:<br>
        <input type="text" name="phone"><br>
        Имя:<br>
        <input type="text" name="name"><br>
        <input type="button" id="send" value="Отправить">
    </form>
    <div id="result"></div>
    <script src="script.js"></script>
</div>
<?php 
    //Подключение подвала
    require_once("footer.php");
?>
</body>
</html>