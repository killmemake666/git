<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href ="css/style.css" rel="stylesheet" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Main</title> 
    <script>
    function index() {
        window.location = "http://test2/index.php"
    }
  </script>
</head>
<body>
<?php 
    //Подключение шапки
    require_once("header.php");
?>
<div id="content1">
    <ul>
		<li class="index"><a href="/page1.php" class="ct">Запись к врачу</a></li>
		<li class="index"><a href="/page2.php" class="ct">Восстановление документов</a></li>
		<li class="index"><a href="/page3.php" class="ct">Регистрация рождения ребенка</a></li>
		<li class="index"><a href="/page4.php" class="ct">Информация о рынке труда</a></li>
		<li class="index"><a href="/page5.php" class="ct">Оздоровительный отдых для детей</a></li>
		<li class="index"><a href="/page6.php" class="ct">Справка об отсутствии судимости</a></li>
	</ul>
</div>
<div id="RaA">
    <input type="button" id="form_register" class="buttons" value="Регистрация" onclick="index()"><br>
    <input type="button" id="form_auth" class="buttons" value="Авторизация" onclick="index()">
</div>
<?php 
    //Подключение подвала
    require_once("footer.php");
?>
</body>
</html>