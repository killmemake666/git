<?php
//Запускаем сессию
session_start();
require_once ("header.php");
include_once("dbconnect.php");


$surname = isset($_GET['surname']) ? trim(strip_tags($_GET['surname'])) : null;
$name = isset($_GET['name']) ? trim(strip_tags($_GET['name'])) : null;
$patronymic = isset($_GET['patronymic']) ? trim(strip_tags($_GET['patronymic'])) : null;
$passport = isset($_GET['passport']) ? trim(strip_tags($_GET['passport'])) : null;
$tbook = isset($_GET['tbook']) ? trim(strip_tags($_GET['tbook'])) : null;
$email = isset($_GET['email']) ? trim(strip_tags($_GET['email'])) : null;
$phone = isset($_GET['phone']) ? trim(strip_tags($_GET['phone'])) : null;
$data = date("d.m.Y"); 
$time = date("H:i:s");

$result_query_insert = $mysqli->query("INSERT INTO `page4` (surname, name, patronymic, passport, tbook,email, phone, data, time) VALUES ('".$surname."', '".$name."','".$patronymic."','".$passport."','".$tbook."','".$email."','".$phone."','".$data."','".$time."')");
mysqli_close($mysqli);
?>
 