$(document).ready(function(){

    $("#contactForm").submit(function(){
        $.ajax ({
            type: "GET",
            url: "handler1.php",
            data: $(this).serialize()
        }).done(function(){
            alert("Всё хорошо");
            window.setTimeout( function(){
                window.location = "http://main";
            }, 3000 );

        });
        return false;
    });
});