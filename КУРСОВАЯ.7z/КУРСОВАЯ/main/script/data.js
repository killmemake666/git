function Formdata(data){
    /* Фамилия */
    if(data.surname != null && data.surname.value.length == 0)
    {
    alert('поле "Фамилия" пустое');
    return false;}
    
    /* Имя */
    if(data.name != null && data.name.value.length == 0)
    {
    alert('поле "Имя" пустое');
    return false;}
    
    /* Отчество */
    if(data.patronymic != null && data.patronymic.value.length == 0)
    {
    alert('поле "Отчество" пустое');
    return false;}

    
    /* Снилс */
    if(data.snils != null && data.snils.value.length == 0)
    {
    alert('поле "Снилс" пустое');
    return false;}
    
    /* Полис */
    if(data.polis != null && data.polis.value.length == 0)
    {
    alert('поле "Полис" пустое');
    return false;}

    /* ИНН */
    if(data.INN != null && data.INN.value.length == 0)
    {
    alert('поле "ИНН" пустое');
    return false;}

    /* Паспорт */
    if(data.passport != null && data.passport.value.length == 0)
    {
    alert('поле "Паспорт" пустое');
    return false;}

    /* Трудовая книжка */
    if(data.tbook != null && data.tbook.value.length == 0)
    {
    alert('поле "Трудовая книжка" пустое');
    return false;}


    /* e-mail Юзера */
    if(data.email != null && data.email.value.length == 0)
    {
    alert('поле "E-Mail" пустое');
    return false;}
    
    if(!(/^[a-z0-9][a-z0-9\._-]*[a-z0-9]*@([a-z0-9]+([a-z0-9-]*[a-z0-9]+)*\.)+[a-z]+/i.test(data.email.value)) )
    {
    alert("Введите правильный E-Mail адрес");
    return false;}
    

    /* контактный телефон */
    if(data.phone != null && data.phone.value.length == 0)
    {
    alert('поле "Контактный телефон" пустое');
    return false;}
}  