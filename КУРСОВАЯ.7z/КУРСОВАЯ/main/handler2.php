<?php
//Запускаем сессию
session_start();
require_once ("header.php");
include_once("dbconnect.php");


$surname = isset($_POST['surname']) ? trim(strip_tags($_POST['surname'])) : null;
$name = isset($_POST['name']) ? trim(strip_tags($_POST['name'])) : null;
$patronymic = isset($_POST['patronymic']) ? trim(strip_tags($_POST['patronymic'])) : null;
$passport = isset($_POST['passport']) ? trim(strip_tags($_POST['passport'])) : null;
$email = isset($_POST['email']) ? trim(strip_tags($_POST['email'])) : null;
$phone = isset($_POST['phone']) ? trim(strip_tags($_POST['phone'])) : null;
$data = date("d.m.Y"); 
$time = date("H:i:s");

$result_query_insert = $mysqli->query("INSERT INTO `page3` (surname, name, patronymic, passport, email, phone, data, time) VALUES ('".$surname."', '".$name."','".$patronymic."','".$passport."','".$email."','".$phone."','".$data."','".$time."')");
mysqli_close($mysqli);
?>
 