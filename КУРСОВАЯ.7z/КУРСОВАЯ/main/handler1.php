<?php
//Запускаем сессию
session_start();
require_once ("header.php");
include_once("dbconnect.php");


$surname = isset($_GET['surname']) ? trim(strip_tags($_GET['surname'])) : null;
$name = isset($_GET['name']) ? trim(strip_tags($_GET['name'])) : null;
$patronymic = isset($_GET['patronymic']) ? trim(strip_tags($_GET['patronymic'])) : null;
$polis = isset($_GET['polis']) ? trim(strip_tags($_GET['polis'])) : null;
$INN = isset($_GET['INN']) ? trim(strip_tags($_GET['INN'])) : null;
$passport = isset($_GET['passport']) ? trim(strip_tags($_GET['passport'])) : null;
$phone = isset($_GET['phone']) ? trim(strip_tags($_GET['phone'])) : null;
$data = date("d.m.Y"); 
$time = date("H:i:s");

$result_query_insert = $mysqli->query("INSERT INTO `page2` (surname, name, patronymic, polis, inn, passport, phone, data, time) VALUES ('".$surname."', '".$name."','".$patronymic."','".$polis."','".$INN."','".$passport."','".$phone."','".$data."','".$time."')");
mysqli_close($mysqli);
?>
 