<?php
//Запускаем сессию
session_start();

require_once ("header.php");

require_once("dbconnect.php");


$surname = isset($_POST['surname']) ? trim(strip_tags($_POST['surname'])) : null;
$name = isset($_POST['name']) ? trim(strip_tags($_POST['name'])) : null;
$patronymic = isset($_POST['patronymic']) ? trim(strip_tags($_POST['patronymic'])) : null;
$snils = isset($_POST['snils']) ? trim(strip_tags($_POST['snils'])) : null;
$email = isset($_POST['email']) ? trim(strip_tags($_POST['email'])) : null;
$phone = isset($_POST['phone']) ? trim(strip_tags($_POST['phone'])) : null;
$data = date("d.m.Y"); 
$time = date("H:i:s");

$result_query_insert = $mysqli->query("INSERT INTO `page1` (surname, name, patronymic, snils, email, phone, data, time) VALUES ('".$surname."', '".$name."','".$patronymic."','".$snils."','".$email."','".$phone."','".$data."','".$time."')");
mysqli_close($mysqli);   
?>


