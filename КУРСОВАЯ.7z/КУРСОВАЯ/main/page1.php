<?php
require_once ("header.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <script type="text/javascript" src="script/data.js"></script>
    <title>Получение загранпаспорта</title>
</head>
<body>
    <div class="container" >
      <div id="response">
        <h2>Получение загранпаспорта</h2>
        <form id="contactForm" name="OurForm">
          <div class="field-block">
            <label for="surname">Фамилия:</label>
            <input id="surname" class="field" name="surname" required type="text" placeholder="Введите фамилию">
          </div>
          <div class="field-block">
            <label for="name">Имя:</label>
            <input id="name" class="field" name="name" required type="text" placeholder="Введите имя">
          </div>
          <div class="field-block">
            <label for="patronymic">Отчество:</label>
            <input id="patronymic" class="field" name="patronymic" required type="text" placeholder="Введите отчество">
          </div>
          <div class="field-block">
            <label for="name">Снилс:</label>
            <input id="snils" class="field" name="snils" required type="text" placeholder="Введите снилс">
          </div>
          <div class="field-block">
            <label for="email">E-mail:</label>
            <input id="email" class="field" name="email" required type="email" placeholder="Введите e-mail">
          </div>
          <div class="field-block">
            <label for="phone">Телефон:</label>
            <input id="phone" class="field" name="phone" required type="text" placeholder="Номер телефона">
          </div>
          <button id="button" class="button" type="submit" onClick="return Formdata(this.form)">Отправить</button>
          <div class="result">
            <span id="answer"></span>
          </div>
        </form>
      </div>
      </div>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
      <script src="http://code.jquery.com/jquery-3.3.1.js"
      integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
      crossorigin="anonymous"></script>  
      <script src='script/script.js'></script> 
      <script src="script/jquery.maskedinput.min.js"></script>
      <script>
        $('#phone').mask('+7 (999) 999-99-99');
        $('#snils').mask('999-999-999 99');
        $('#passport').mask('99-99 999999');
        $('#INN').mask('999999999999');
        $('#polis').mask('9999999999999999');
      </script>
</body>
</html>