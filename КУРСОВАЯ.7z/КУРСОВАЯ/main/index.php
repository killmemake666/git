<?php
require_once ("header.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Главная страница</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>
    <div class="container">
    <div class="zornet_ru">
  <ul>
    <li><a class="text" href="page1.php">Получение загранпаспорта</a></li>
    <li><a class="text" href="page3.php">Справка об отсутствии судимости</a></li>
  </ul>
  <ul>
    <li><a class="text" href="page2.php">Запись к врачу</a></li>
    <li><a class="text" href="page4.php">Установление пенсии</a></li>
  </ul>
    </div>
</div>    
</body>
</html>