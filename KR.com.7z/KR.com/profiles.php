<?php 
    //Подключение шапки
    require_once("header.php");
    
?>
<?php
	$dblocation = "localhost";
	$dbname = "users";
	$dbuser = "root";
	$dbpasswd = "";
	
	$dbcnx = @mysql_connect($dblocation,$dbuser,$dbpasswd);
	if(!$dbcnx){
		echo("В настоящих момент сервер базы данных не доступен");
	exit();
	}
	
	if(! @mysql_select_db($dbname,$dbcnx) ){
		echo("В настоящих момент база данных не доступна");
	exit();
	}
	$t = $_SESSION['email'];
	$query = "SELECT * FROM users WHERE email = '$t'";
	$str = mysql_query($query);
	if(!$str) exit("Ошибка в синтаксисе SQL-запроса");
	while ($sql = mysql_fetch_array($str))
	{
		echo "Имя - $sql[first_name]<br>Фамилия - $sql[last_name]<br>Снилс - $sql[snils]<br>Почта - $sql[email]<br>";
	}
?>


<?php 
    //Подключение подвала
    require_once("footer.php");
?>