<?php
if (basename($_SERVER['REQUEST_URI']) == 'index.php') { 
$title = 'Главная страница'; 
}
if (basename($_SERVER['REQUEST_URI']) == 'form_register.php') { 
$title = 'Регистрация'; 
}  
if (basename($_SERVER['REQUEST_URI']) == 'form_auth.php') { 
$title = 'Авторизация'; 
}
if (basename($_SERVER['REQUEST_URI']) == 'profiles.php') { 
$title = 'Профиль'; 
} 
if (basename($_SERVER['REQUEST_URI']) == 'page1.php') { 
$title = 'Страница 1'; 
} 
if (basename($_SERVER['REQUEST_URI']) == 'page2.php') { 
$title = 'Страница 2'; 
} 
if (basename($_SERVER['REQUEST_URI']) == 'page3.php') { 
$title = 'Страница 3'; 
} 
if (basename($_SERVER['REQUEST_URI']) == 'page4.php') { 
$title = 'Страница 4'; 
} 
if (basename($_SERVER['REQUEST_URI']) == 'page5.php') { 
$title = 'Страница 5'; 
} 
if (basename($_SERVER['REQUEST_URI']) == 'page6.php') { 
$title = 'Страница 6'; 
} 
?>