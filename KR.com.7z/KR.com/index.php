<?php 
    //Подключение шапки
    require_once("header.php");
?>

<div id="content">
    <ul>
		<li class="index"><a href="/page1.php" class="ct">Запись к врачу</a></li>
		<li class="index"><a href="/page2.php" class="ct">Восстановление документов</a></li>
		<li class="index"><a href="/page3.php" class="ct">Регистрация рождения ребенка</a></li>
		<li class="index"><a href="/page4.php" class="ct">Информация о рынке труда</a></li>
		<li class="index"><a href="/page5.php" class="ct">Оздоровительный отдых для детей</a></li>
		<li class="index"><a href="/page6.php" class="ct">Справка об отсутствии судимости</a></li>
	</ul>
</div>

<?php 
    //Подключение подвала
    require_once("footer.php");
?>