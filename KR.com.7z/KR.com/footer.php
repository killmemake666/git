
<div id="footer">
  <h2>Подвал</h2>
</div>

</body>
</html>