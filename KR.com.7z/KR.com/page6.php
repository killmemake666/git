<?php 
    //Подключение шапки
    require_once("header.php");
?>

<center><h2>Страница 6</h2></center>

<?php 
    //Подключение подвала
    require_once("footer.php");
?>