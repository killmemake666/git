var http = require('http');
var url = require('url');
var querystring = require('querystring');
var fs = require('fs');
http.createServer(function (req, res) {
	if(req.url === '/index.html' || req.url === '/'){
		res.writeHead(200, {'Content-Type': 'text/html'});
		fs.createReadStream(__dirname + '/index.html').pipe(res);
	}else if(req.url === '/page1.html'){
		res.writeHead(200, {'Content-Type': 'text/html'});
		fs.createReadStream(__dirname + '/page1.html').pipe(res);
	}else if(req.url === '/page2.html'){
		res.writeHead(200, {'Content-Type': 'text/html'});
		fs.createReadStream(__dirname + '/page2.html').pipe(res);	
	}else{
		res.writeHead(404, {'Content-Type': 'text/html'});
		fs.createReadStream(__dirname + '/404.html').pipe(res);
	}
}).listen(8080);
console.log("Server running at http://127.0.0.1:8080/");